export class Employee{
    empId:string;
    empName:string;
    empSal:string;
    empDep:string;

    public constructor(empId:string,empName:string,empSal:string,empDep:string){
        this.empId=empId;
        this.empName=empName;
        this.empSal=empSal;
        this.empDep=empDep;
    }
}
