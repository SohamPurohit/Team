import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders}from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './Employee';

@Injectable({
  providedIn: 'root'
})
export class CrudService {
  

  localurl:string='./assets/data.json'
 
  constructor(private http:HttpClient){ }

  //Http Header
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
  }

  //Get data from data.json
  GetData():Observable<Employee>{
    return this.http.get<Employee>(this.localurl);
  }

 
}