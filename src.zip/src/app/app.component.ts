import { Component,OnInit } from '@angular/core';
import { CrudService } from './crud.service';
import { Employee } from './Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EmployeeCrud';
  employees:any[];
  empId:string;
  empName:string;
  empSal:string;
  empDep:string;
  
  constructor(private cs:CrudService){
    
  }

  ngOnInit(){
    this.loadData();

  }

  //Load data from GetData()
  loadData(){
    return this.cs.GetData().subscribe( (data:any)=>{ this.employees=data;
    })
  }


  //adding new Employee
  addEmployee(event){
    this.empId =(<HTMLInputElement>document.getElementById("id")).value;
    this.empName =(<HTMLInputElement>document.getElementById("name")).value;
    this.empSal =(<HTMLInputElement>document.getElementById("salary")).value;
    this.empDep =(<HTMLInputElement>document.getElementById("department")).value;
    var employee = new Employee(this.empId,this.empName,this.empSal,this.empDep);
    this.employees.push(employee);

    (<HTMLInputElement>document.getElementById("id")).value="";
    (<HTMLInputElement>document.getElementById("name")).value="";
    (<HTMLInputElement>document.getElementById("salary")).value="";
    (<HTMLInputElement>document.getElementById("department")).value="";
    document.getElementById("msg").innerHTML="Emplyee Added"; 

  }


  //deleting Employee
  delEmployee(empId){
    for( var i=0;i<this.employees.length;i++){
      if(this.employees[i].empId==empId){
        this.employees.splice(i,1);
      }
    }
    document.getElementById("msg").innerHTML="Emplyee Deleted";
  }


  //update (taking values from the previous data to update form)
  update(empId,empName,empSal,empDep){
    
        (<HTMLInputElement>document.getElementById("id1")).value=empId;
        (<HTMLInputElement>document.getElementById("name1")).value=empName;
        (<HTMLInputElement>document.getElementById("salary1")).value=empSal;
        (<HTMLInputElement>document.getElementById("department1")).value=empDep; 
        //this.delEmployee(empId);
    
  }

  updateEmployee(event){
    
    this.empId =(<HTMLInputElement>document.getElementById("id1")).value;
    this.empName =(<HTMLInputElement>document.getElementById("name1")).value;
    this.empSal =(<HTMLInputElement>document.getElementById("salary1")).value;
    this.empDep =(<HTMLInputElement>document.getElementById("department1")).value;
    var employee = new Employee(this.empId,this.empName,this.empSal,this.empDep);
    

    for( var i=0;i<this.employees.length;i++){
      if(this.employees[i].empId==this.empId){
        this.employees[i].empName=this.empName;
        this.employees[i].empSal=this.empSal;
        this.employees[i].empDep=this.empDep;
      }
    }
    (<HTMLInputElement>document.getElementById("id1")).value="";
    (<HTMLInputElement>document.getElementById("name1")).value="";
    (<HTMLInputElement>document.getElementById("salary1")).value="";
    (<HTMLInputElement>document.getElementById("department1")).value=""; 
    document.getElementById("msg").innerHTML="Emplyee Updated";

    
  }
}

